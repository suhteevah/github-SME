# HANDOFF.md — Course Review Agent Pipeline

## Last Updated
2026-03-25

## Project Status
🟡 SCAFFOLDING — Skill designed, architecture defined, awaiting first course package from client

## Current State

### What's Done
- [x] SKILL.md written with full agent pipeline architecture
- [x] CLAUDE.md (soul file) written with coding standards, architecture, and integration notes
- [x] HANDOFF.md (this file) created
- [x] Skill packaged as .skill file for installation
- [x] Upwork proposal submitted at $45/hr (flat rate per course applies: $200-$360)
- [x] Course priorities selected: Speed Up CI Pipeline, Manage Code with Git Bots, Orchestrate Agents Efficiently, Build & Document Microservice, Containerise & Deploy Fast

### What's Next (in order)
1. **AWAIT:** Client response on Upwork — interview/acceptance
2. **RECORD:** 1-minute intro video using their C# audition script template
3. **BUILD:** Implement the agent pipeline (Rust + Python scripts)
   - Start with Python scripts (fastest to deploy)
   - Port to Rust agents once pipeline is validated
4. **TEST:** Run pipeline against sample course materials (create fixtures)
5. **DEPLOY:** Process first real course package when it arrives

### Blocking Issues
- No course materials received yet — need client to assign courses
- 1-minute intro video not yet recorded (required for evaluation)
- Tier assignment (Regular $200 / Senior $280 / Special $360) not confirmed — push for Special

### Agent Implementation Priority
Build in this order (Python first, fastest to revenue):
1. `review_single.py` — Review any single file (most immediately useful)
2. `review_course.py` — Full course pipeline orchestrator
3. `validate_links.py` — URL checker (quick win, reusable)
4. `check_versions.py` — Version currency validator (web search powered)
5. `generate_lab.py` — Lab generator (needed for deliverable #7 in contract)
6. `prep_screencast.py` — Screencast preparation (needed before recording)
7. `incorporate_feedback.py` — Feedback incorporation (needed for revision rounds)

### Key Files
- Skill definition: `course-review-agent/SKILL.md`
- Soul file: `CLAUDE.md`
- This file: `HANDOFF.md`

### Notes for Next Session
- The Upwork contract specifies milestone-based payments:
  - 25% at outline creation/reviews
  - 35% at content reviews/validation/code testing
  - 20% at screencast/demo delivery
  - 20% at talking head video recording + digital signature
- Client expects 1 round of internal feedback + 2 rounds of client feedback per deliverable
- Talking head videos are 35-45 minutes of recording per course
- Matt needs to record the 1-minute C# audition video ASAP — this is mandatory for evaluation
- Digital signature required for client platform
